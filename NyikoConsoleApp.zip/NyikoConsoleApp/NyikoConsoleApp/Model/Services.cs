﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NyikoConsoleApp.Model
{
    public class Response
    {
        public string element { get; set; }
        public string regex { get; set; }
        public string identifier { get; set; }
    }
    public class Identifier
    {
        public string key { get; set; }
        public string value { get; set; }
    }

    public class Endpoint
    {
        public bool enabled { get; set; }
        public string resource { get; set; }
        public IList<Response> response { get; set; }
    }

    public class Service
    {
        public string baseURL { get; set; }
        public string datatype { get; set; }
        public bool enabled { get; set; }
        public IList<Endpoint> endpoints { get; set; }
        public List<Identifier> identifiers { get; set; }
    }

    public class Root
    {
        public IList<Service> services { get; set; }
    }
}
